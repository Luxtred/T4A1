package t4a1;

import java.util.Scanner;

public class T4A1 {

public static void main(String[] args) {
       //ejercicio1();
       //ejercicio2();
       //ejercicio3();
       ejercicio4();
    }

    public static void ejercicio1 () {
        //1. Escribir un programa que solicite un n�mero positivo y nos muestre desde 1 hasta el valor ingresado de uno en uno. 
        Scanner scanner = new Scanner(System.in);
        int numero=0; 
        
        System.out.println("Hasta donde desea llegar: ");
        int limite =scanner.nextInt();
        
        while ( numero < limite){
            numero++;
            System.out.println(numero);
        }             
    }
    
public static void ejercicio2(){
    // 2. Crear un programa en Java que solicite la cantidad de piezas a confeccionar y luego se ingrese las respectivas tallas que pueden ser S, M, L y XL. 
    //Luego, imprimir en pantalla la cantidad de piezas confeccionadas por talla.
    Scanner scanner = new Scanner(System.in);
    
    System.out.print("Piezas a confeccionar \n ");
    
    int confecciones = scanner.nextInt();
    int n = 0;
    int tallaS= 0;
    int tallaM= 0;
    int tallaL= 0;
    int tallaXL=0;
    
    while (n < confecciones){
     n++;   
     
        System.out.println("\nTalla: ");
        String tallas = scanner.next();
        
        if (tallas.equals("S")||tallas.equals("s")){
            tallaS++;
        } else if (tallas.equals("M")||tallas.equals("m")) {
            tallaM++;
        }else if  (tallas.equals("L")||tallas.equals("l")) {
            tallaL++;  
        } else {
            tallaXL++; 
       }
     }
    System.out.print(n + "Cantidades por talla: \n"
            + "Chica (S)" + "\t\t\t" + tallaS + "\n"
            + "Mediana (M)" + "\t\t\t" + tallaM + "\n"
            + "Grande (L)" + "\t\t\t" + tallaL + "\n"
            + "Extra Grande (XL)" + "\t" + tallaXL);
    }

public static void ejercicio3(){
     Scanner scanner = new Scanner(System.in);
     //Escribir un programa en Java que solicite N calificaciones de estudiantes en una escala del 0 al 100 y que informe cu�ntos tienen 
     //calificaci�n mayor o igual a 70 y cu�ntos tienen una calificaci�n menor.
     int calificacion, contadorA = 0, contadorB = 0;
     
char res;
do { System.out.print("Ingrese su calificaci�n en escala de 0 a 100: ");

calificacion = scanner.nextInt();

if(calificacion>=70){
    contadorA++;
}else{
    contadorB++;
}
 System.out.print("�Desea ingresar otra calificaci�n? (S/N): ");
 res = scanner.next().toUpperCase().charAt(0);
} while(res=='S');

System.out.println("Los estudiantes con una calificaci�n igual o mayor a 70 son: " + contadorA);
System.out.println("Los estudiantes con una calificaci�n menor a 70 son: " + contadorB);
     }
     

public static void ejercicio4(){
     Scanner scanner = new Scanner(System.in);
     //Escribir un programa en Java que imprima los m�ltiplos del n�mero que indique el usuario hasta la cantidad deseada. El usuario debe indicar 
     //el m�ltiplo y el n�mero hasta el cual quiere llegar.
     
     int num,mult,res;
    System.out.print("Ingrese un n�mero: ");
    num= scanner.nextInt();
    System.out.print("Ingrese un n�mero: ");
    mult= scanner.nextInt();

for(int i=1;i<mult;i++){
    
res=num*i;

    System.out.println(num+" * "+i+" = "+res);
    
}
     
}

}